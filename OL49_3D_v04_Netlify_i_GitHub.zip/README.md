# OL49 — Linia Próbna v0.4 (3D)

Projekt rozwija grę **Ol49_v0.2_Netlify.zip** z Dysku Google, a nie wersję 2D.

## Uruchomienie

Wgraj katalog zawierający `index.html` do Netlify (w tym samym projekcie, na zakładce Deploys, jeśli chcesz zachować aktualny adres). Alternatywnie przesłanie pliku do gałęzi `main` w repozytorium GitHub zastąpi stronę GitHub Pages po wdrożeniu.

Gra wymaga aktywnego internetu do pobrania biblioteki Three.js z CDN. Użyj Safari na iPhonie w orientacji pionowej lub poziomej.

## Rozbudowa

- OL49-59: model 3D z dużymi kołami napędnymi (średnica 1,75 m), osiami tocznymi 0,85 m, tendrem 25D49 (4 osie na 2 wózkach).
- Nowe wiatrownice, szczegóły drzwi dymnicy, zawory, przewody parowe, detale budki, osprzęt i oznakowanie tendra.
- Nowe widoki: WIĄZARY i DYMNICA — przycisk KAMERA przełącza sześć widoków.
- Kocioł: ciśnienie, poziom wody, żar paleniska, inżektor, dosypywanie węgla, napełnianie tendra.
- Dwie stacje: Leśna i Tartak, postój i uzupełnianie wody.
- Zapis/wczytanie lokalne przeglądarki (klucz `ol49-linia-v03-3d-save`).

## Ograniczenia

To **model proceduralny inspirowany Ol49**, nie pomiarowy CAD 1:1. Sterowanie kotłem i dynamika są uproszczone. Aktualizacje strony nie są automatycznie wdrażane przez ChatGPT na Netlify. Na GitHubie połączenie pozwala odczytać kod, ale próba zapisu dała HTTP 403. Testowana składnia i podstawowe obliczenia; nie ukończono renderowego testu na fizycznym iPhonie.

## Materiały porównawcze

- Skansen Chabówka: https://www.parowozy.pl/ekspozycja/lokomotywy-parowe/ol49/
- Era Parowozów: https://eraparowozow.org.pl/portret-parowozu-ol49/
- Parowozy.net: https://www.parowozy.net/parowozy/ol49
