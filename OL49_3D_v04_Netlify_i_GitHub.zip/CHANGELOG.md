# Historia zmian

## v0.4

- Ulepszono kształt OL49: wiatrownice, detal drzwi dymnicy, osprzęt kotła, cięgła, stopnie, detale budki, poszerzony detal tendra 25D49.
- Rozbudowano o tryby kamery WIĄZARY i DYMNICA.
- Zachowano wersję gry 3D, kotła, stacji i zapisów z prototypu v0.3.

## v0.3

- Kocioł, paliwo, dwa postoje, żurawie wodne, zapis/wczytywanie.

## v0.2

- Oryginalne 3D Three.js z lokomotywą, tendrem, scenerią, dźwiękiem i sterowaniem na telefonie.
